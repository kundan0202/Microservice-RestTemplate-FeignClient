package com.example.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.client.GreetFeignClient;

@RestController
public class WelcomeController {
	
	@Autowired
	private GreetFeignClient greetClient;
	
	@GetMapping("/welcome")
	public String welcomeMsg() {
		String msg = "Client -2: Welcome Api";
		
		String greetResponse = greetClient.invokeGreetApi();
		
		String finalResponse =greetResponse + " : " + msg;
		return finalResponse;
	}

}
