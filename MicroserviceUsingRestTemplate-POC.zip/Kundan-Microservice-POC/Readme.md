# Imlpementing  Microservices with Springboot

  We use Spring Boot to build our microservices. Spring boot projects can easily be configured using the spring initializer or using IDE.

  This project gives complete solution,how services are routed using Api Gateway and registerd to Eureka server.
 
 #service-registry application :
 
 This application register all the spring boot application to Eureka Server. Also this application runs on port no: 8761
 
 URL: http://localhost:8761/
 
 #Api-gateway application:
 
 This application developed using Zuul Proxy . All the routing routes are specified in this application.
 This runs on Port:9292 & URL:  http://localhost:9292/
 
 Pathology-service application:
 
 This application gives list of diseases and their possible treatment.This runs on Port:8888
 URL: http://localhost:8888/pathology/diseases
 
 HR-service application:
 
 This application provides list of doctors/physicians and their specialization details.This runs on Port:5555
 URL: http://localhost:5555/hr/employees
 
 Admissions-service application:
 
 This application gives patients details such as patient id ,name and their address.
 Also,this application tries to communicae with HR-service & Pathology-service using REST Template.
 This runs on Port:6666
 URL: http://localhost:6666/admissions/patients
 
 # How to run & test the project
 
  Import the project as maven project in STS(ide)
  Run each application as Springboot App:-
  First start Eureka Server Application
  Next,Run other applications-Pathology-service,HR-service,Admissions-service,Api-Gateway
  
 # How to test the project:
 
   Tested & Verified using Postman client
   
   PFB URLs to test:-

  Intercommunication b/w Admissions & HR Api        ==>  http://localhost:6666/admissions/physicians
  Intercommunication b/w Admissions & Pathology Api ==>  http://localhost:6666/admissions/diseases
  
  Api gateway routing:-

	HR api  ----------------------> http://localhost:9292/api/hr
	Pathology api ----------------> http://localhost:9292/api/pat
	Admissions api----------------> http://localhost:9292/api/adm