package com.example;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;

@SpringBootApplication
@EnableDiscoveryClient
public class PathologyApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(PathologyApiApplication.class, args);
	}

	
	//list of diseases
}
