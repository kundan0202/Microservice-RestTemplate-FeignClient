package com.example.entity;

public class Disease {

	private String diseaseType;
	private String diseaseName;
	private String treatment;
	
	
	public Disease(String diseaseType, String diseaseName, String treatment) {
		super();
		this.diseaseType = diseaseType;
		this.diseaseName = diseaseName;
		this.treatment = treatment;
	}

	public String getDiseaseType() {
		return diseaseType;
	}

	public void setDiseaseType(String diseaseType) {
		this.diseaseType = diseaseType;
	}

	public String getDiseaseName() {
		return diseaseName;
	}

	public void setDiseaseName(String diseaseName) {
		this.diseaseName = diseaseName;
	}

	public String getTreatment() {
		return treatment;
	}

	public void setTreatment(String treatment) {
		this.treatment = treatment;
	}

	@Override
	public String toString() {
		return "Disease [diseaseType=" + diseaseType + ", diseaseName=" + diseaseName + ", treatment=" + treatment
				+ "]";
	}

	
}
