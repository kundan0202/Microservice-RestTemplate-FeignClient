package com.example.entity;

import java.util.List;

public class DiseasesList {

	private List<Disease> diseases;

	public List<Disease> getDiseases() {
		return diseases;
	}

	public void setDiseases(List<Disease> diseases) {
		this.diseases = diseases;
	}	
}
