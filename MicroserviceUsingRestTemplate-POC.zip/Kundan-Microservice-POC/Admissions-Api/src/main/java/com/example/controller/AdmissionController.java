package com.example.controller;

import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.example.entity.DiseasesList;
import com.example.entity.EmployeesList;
import com.example.entity.Patient;
import com.example.entity.PatientList;
import com.example.entity.Disease;
import com.example.entity.Employee;

@RestController
@RequestMapping("/admissions")
public class AdmissionController {
	
	
	  @Autowired
	  private RestTemplate restTemplate;
	 
	
	//A hardcoded list of patients
		private List<Patient> patients = Arrays.asList(			
		new Patient("P1", "Joseph", "Nigeria"),
		new Patient("P2", "Gabor", "Hungary"),
		new Patient("P3", "Govind", "India")
		);
	
	//getPatients() returns a list of patients
	@GetMapping("/patients")
	public PatientList getPatients() {
		PatientList patientList =new PatientList();
		patientList.setPatients(patients);
		return patientList;
		
		
	}
	
	//getPatientById() returns a patient with a given Id
	@RequestMapping("/patients/{Id}")
	public Patient getPatientById(@PathVariable("Id") String Id) {
		Patient p = patients.stream()
				.filter(patient -> Id.equals(patient.getId()))
				.findAny()
				.orElse(null);
		return p;
	}
	
	
	//getPhysicians calls the hr-service microservice to get list of physicians
	@RequestMapping("/physicians")
	public EmployeesList getPhysicians() {
		EmployeesList physicians = 
				restTemplate.getForObject("http://localhost:5555/hr/employees", EmployeesList.class);
		return physicians;
	}
	
	//getDiseases calls the pathology-service to get list of diseases
	@RequestMapping("/diseases")
	public DiseasesList getDiseases() {
		DiseasesList diseases = 
				restTemplate.getForObject("http://localhost:8888/pathology/diseases", DiseasesList.class);
		return diseases;
	}
	

}
