package com.example.entity;

public class Employee {

	private String empId;
	private String name;
	private String address;
	private String technology;
	
	public Employee(String empId, String name, String address, String technology) {
		super();
		this.empId = empId;
		this.name = name;
		this.address = address;
		this.technology = technology;
	}
	
	public String getEmpId() {
		return empId;
	}
	public void setEmpId(String empId) {
		this.empId = empId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}

	public String getTechnology() {
		return technology;
	}

	public void setTechnology(String technology) {
		this.technology = technology;
	}
	
	@Override
	public String toString() {
		return "Employee [empId=" + empId + ", name=" + name + ", address=" + address + ", technology=" + technology
				+ "]";
	}


}

